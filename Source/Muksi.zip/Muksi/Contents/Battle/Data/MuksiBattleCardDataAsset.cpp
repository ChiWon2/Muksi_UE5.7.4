#include "Muksi/Contents/Battle/Data/MuksiBattleCardDataAsset.h"

UMuksiBattleCardDataAsset::UMuksiBattleCardDataAsset()
{
	CardID = NAME_None;
	CardName = FText::FromString(TEXT("Default Card"));
	CardDescription = FText::FromString(TEXT("Card Description"));
	CardTexture = nullptr;
}

/*UMuksiBattleCardDataAsset* UMuksiBattleCardDataAsset::GetActualCard() const
{
	if (!bIsDeceiveCard || !IsValid(ActualCard) || ActualCard.Get() == this)
		return nullptr;

	return ActualCard.Get();
}*/

UMuksiBattleCardDataAsset* UMuksiBattleCardDataAsset::GetDeceivedCard() const
{
	if (!bIsDeceiveCard || !IsValid(DeceivedCard) || DeceivedCard.Get() == this)
		return nullptr;
	return DeceivedCard.Get();
}


#if WITH_EDITOR

void UMuksiBattleCardDataAsset::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	SyncExecutionDataTypes();
	SyncTargetingDataTypes();
}

void UMuksiBattleCardDataAsset::SyncExecutionDataTypes()
{
	for (FBattleExecutionEntry& Entry : MainExecutionEntries)
	{
		Entry.SyncExecutionDataType();
	}

	for (FBattleExecutionNotify& ExecutionNotify : ExecutionNotifies)
	{
		ExecutionNotify.SyncExecutionDataTypes();
	}
}

void UMuksiBattleCardDataAsset::SyncTargetingDataTypes()
{
	TargetingData.SyncDataTypes();
}





#endif

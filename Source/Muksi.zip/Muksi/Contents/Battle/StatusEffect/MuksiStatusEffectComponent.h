#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Muksi/Contents/Battle/Data/BattlePhase.h"
#include "MuksiStatusEffectComponent.generated.h"

class ABattleManager;
class UMuksiStatusEffect;
class UBattleExecutionRunner;
class UStatusEffectDefinitionDataAsset;
struct FBattleAction;
struct FBattleExecutionContext;
struct FBattleExecutionEntry;

DECLARE_MULTICAST_DELEGATE(FOnStatusEffectsChanged);

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class MUKSI_API UMuksiStatusEffectComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UMuksiStatusEffectComponent();

public:
    FOnStatusEffectsChanged OnStatusEffectsChanged;

public:
    void Initialize(ABattleManager* InBattleManager);
	void ResetRuntimeState();

    UFUNCTION(BlueprintCallable)
    UMuksiStatusEffect* AddStatusEffect(FName EffectID, int32 StackCount = 1, int32 Duration = 1);

    UFUNCTION(BlueprintCallable)
    UMuksiStatusEffect* SubtractStatusEffect(FName EffectID, int32 StackCount = 1, int32 Duration = 0);

    UFUNCTION(BlueprintCallable)
    void RemoveStatusEffectByID(FName EffectID);

public:
    UMuksiStatusEffect* FindEffectByID(FName EffectID) const;
    int32 GetEffectStackCount(FName EffectID) const;
    const TArray<TObjectPtr<UMuksiStatusEffect>>& GetActiveEffects() const;
    UStatusEffectDefinitionDataAsset* FindStatusEffectDefinition(FName EffectID) const;
	void AppendHitDealtExecutionEntries(const FBattleExecutionContext& Context, int32 Damage, TArray<FBattleExecutionEntry>& OutExecutionEntries) const;
	void AppendHitReceivedExecutionEntries(const FBattleExecutionContext& Context, int32 Damage, TArray<FBattleExecutionEntry>& OutExecutionEntries) const;
	int32 ApplyIncomingDamageModifiers(int32 Damage, FName& OutHitReactionAnimKey);

    void ExecuteSequentially(EBattlePhase OldPhase, EBattlePhase NewPhase, FSimpleDelegate CompletionDelegate);
	void BeginAppliedFXWait(FSimpleDelegate CompletionDelegate);
	void EndAppliedFXWait();

protected:
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
    UPROPERTY(VisibleAnywhere)
    TArray<TObjectPtr<UMuksiStatusEffect>> ActiveEffects;

    UPROPERTY(Transient)
    TObjectPtr<ABattleManager> BattleManager = nullptr;

    bool RemoveExpiredEffects(bool bNotify = true);
    void RemoveStatusEffect(UMuksiStatusEffect* Effect);
	void HandleBattleActionStarted(FBattleAction& CurrentAction, FBattleAction& OpponentAction);
	void HandleBattleActionCompleted(const FBattleAction& CompletedAction);
	void HandleBattleExchangeCompleted(int32 ExchangeIndex);
	void ApplyStatusEffectToCurrentBattleAction(UMuksiStatusEffect* Effect);
	void PlayAppliedStatusEffectFX(const UStatusEffectDefinitionDataAsset* EffectDefinition);
	void StartStatusEffectAuraFX(const UStatusEffectDefinitionDataAsset* EffectDefinition);
	void StopStatusEffectAuraFX(FName EffectID);
	void HandleAppliedStatusEffectFXFinished();
	void TryFinishAppliedFXWait();
	void CancelAppliedFXWait();
    void ExecuteNextStatusEffect();
    void RunPhaseExecutionEntries(const TArray<FBattleExecutionEntry>& ExecutionEntries);
    void HandlePhaseExecutionRunnerFinished(UBattleExecutionRunner* FinishedRunner);
    void FinishExecution();

    UPROPERTY(Transient)
    TArray<TObjectPtr<UMuksiStatusEffect>> ExecutionQueue;

	UPROPERTY(Transient)
	TObjectPtr<UBattleExecutionRunner> PhaseExecutionRunner = nullptr;

    FSimpleDelegate ExecutionCompletionDelegate;
	FSimpleDelegate AppliedFXWaitCompletionDelegate;
    EBattlePhase ExecutingOldPhase = EBattlePhase::None;
    EBattlePhase ExecutingNewPhase = EBattlePhase::None;
    int32 ExecutionIndex = INDEX_NONE;
    int32 PendingAppliedFXCount = 0;
    bool bExecuting = false;
	bool bAppliedFXWaitActive = false;
	bool bAppliedFXWaitSealed = false;
};

#include "Muksi/Contents/Battle/Execution/Executions/Move/MoveExecution.h"

#include "Muksi/Contents/Battle/Animations/MuksiBattleAnimationComponent.h"
#include "Muksi/Contents/Battle/Character/BattleCharacterBase.h"
#include "Muksi/Contents/Battle/Grid/BattleGridManager.h"
#include "Muksi/Contents/Battle/Grid/Navigation/BattleGridNavigationComponent.h"
#include "Muksi/Contents/Battle/Movement/MuksiBattleMovementComponent.h"

void UMoveExecution::Execute(const FBattleExecutionContext& Context, FBattleExecutionFinished OnFinished)
{
	CachedOnFinished = OnFinished;
	bHasMoveData = false;

	MovingCharacter = Context.Attacker.Get();
	GridManager = Context.BattleGridManager.Get();
	GridWorldType = Context.GridWorldType;

	const FMoveExecutionData* MoveData = Context.GetExecutionData<FMoveExecutionData>();

	if (!MovingCharacter || !GridManager || !MoveData)
	{
		FinishMoveExecution();
		return;
	}

	CachedMoveData = *MoveData;
	bHasMoveData = true;

	NavigationComponent = GridManager->GetNavigationComponent();
	MovementComponent = MovingCharacter->GetBattleMovementComponent();
	AnimationComponent = MovingCharacter->FindComponentByClass<UMuksiBattleAnimationComponent>();

	if (!NavigationComponent || !MovementComponent || !AnimationComponent)
	{
		FinishMoveExecution(true);
		return;
	}

	StartCoord = MovingCharacter->GetCharacterCoord();
	DestinationCoord = Context.GetPrimaryTargetCoord();

	if (!ValidateDestination())
	{
		FinishMoveExecution(true);
		return;
	}

	if (StartCoord == DestinationCoord)
	{
		FinishMoveExecution(true);
		return;
	}

	switch (CachedMoveData.MoveType)
	{
	case EMuksiBattleMoveType::Teleport:
		StartTeleportMovement();
		break;

	case EMuksiBattleMoveType::Jump:
		StartJumpMovement();
		break;

	case EMuksiBattleMoveType::GroundPath:
		StartGroundPathMovement();
		break;

	case EMuksiBattleMoveType::None:
	default:
		FinishMoveExecution();
		break;
	}
}

bool UMoveExecution::ValidateDestination() const
{
	if (!NavigationComponent || !MovingCharacter)
	{
		return false;
	}

	if (DestinationCoord.X == INDEX_NONE || DestinationCoord.Y == INDEX_NONE)
	{
		return false;
	}

	return NavigationComponent->IsCellAvailable(GridWorldType, DestinationCoord, MovingCharacter.Get());
}

void UMoveExecution::StartTeleportMovement()
{
	FVector TargetWorldLocation = FVector::ZeroVector;

	if (!NavigationComponent->GetGridWorldLocation(DestinationCoord, TargetWorldLocation))
	{
		FinishMoveExecution(true);
		return;
	}

	FMuksiBattleMovementFinished OnMovementFinished;
	OnMovementFinished.BindUObject(this, &UMoveExecution::HandleMovementFinished);

	MovementComponent->StartTeleportMove(TargetWorldLocation, OnMovementFinished);
}

void UMoveExecution::StartJumpMovement()
{
	FVector TargetWorldLocation = FVector::ZeroVector;

	if (!NavigationComponent->GetGridWorldLocation(DestinationCoord, TargetWorldLocation))
	{
		FinishMoveExecution(true);
		return;
	}

	FMuksiBattleMovementFinished OnMovementFinished;
	OnMovementFinished.BindUObject(this, &UMoveExecution::HandleMovementFinished);

	MovementComponent->StartArcMove(TargetWorldLocation, CachedMoveData.JumpDuration, CachedMoveData.JumpArcHeight, OnMovementFinished);
}

void UMoveExecution::StartGroundPathMovement()
{
	TArray<FHexOffsetCoord> GridPath;

	if (!NavigationComponent->FindGroundPath(GridWorldType, StartCoord, DestinationCoord, GridPath, MovingCharacter.Get()))
	{
		FinishMoveExecution(true);
		return;
	}

	TArray<FVector> WorldPath;

	if (!NavigationComponent->ConvertGridPathToWorldPath(GridPath, WorldPath))
	{
		FinishMoveExecution(true);
		return;
	}

	if (WorldPath.IsEmpty())
	{
		FinishMoveExecution(true);
		return;
	}

	FMuksiBattleMovementFinished OnMovementFinished;
	OnMovementFinished.BindUObject(this, &UMoveExecution::HandleMovementFinished);

	MovementComponent->StartPathMove(WorldPath, CachedMoveData.GroundMoveSpeed, OnMovementFinished);
}

void UMoveExecution::HandleMovementFinished(bool bInterrupted)
{
	if (IsExecutionFinished())
	{
		return;
	}

	if (bInterrupted)
	{
		RestoreStartWorldLocation();
		FinishMoveExecution(true);
		return;
	}

	if (!CommitGridMovement())
	{
		RestoreStartWorldLocation();
		FinishMoveExecution(true);
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("[MoveExecution] Movement completed. Character=%s Start=(%d, %d) Destination=(%d, %d)"), *GetNameSafe(MovingCharacter.Get()), StartCoord.X, StartCoord.Y, DestinationCoord.X, DestinationCoord.Y);

	FinishMoveExecution(true);
}

bool UMoveExecution::CommitGridMovement()
{
	if (!MovingCharacter || !GridManager || !NavigationComponent)
		return false;

	if (!NavigationComponent->IsCellAvailable(GridWorldType, DestinationCoord, MovingCharacter.Get()))
		return false;

	// Grid 점유와 CharacterData.CurrentPosition을 원자적으로 갱신한다.
	FBattleGridMoveRequest Request;
	Request.Character = MovingCharacter.Get();
	Request.WorldType = GridWorldType;
	Request.FromCoord = StartCoord;
	Request.ToCoord = DestinationCoord;
	Request.bSnapActorToGrid = true;
	Request.bPreserveActorRotation = true;

	return GridManager->ExecuteGridMove(Request).bSucceeded;
}

void UMoveExecution::RestoreStartWorldLocation()
{
	if (!MovingCharacter || !NavigationComponent)
	{
		return;
	}

	FVector StartWorldLocation = FVector::ZeroVector;

	if (NavigationComponent->GetGridWorldLocation(StartCoord, StartWorldLocation))
	{
		MovingCharacter->SetActorLocation(StartWorldLocation);
	}
}

void UMoveExecution::RequestMovementEndAnimation()
{
	if (!AnimationComponent || !bHasMoveData)
		return;

	FName EndSection = NAME_None;

	switch (CachedMoveData.MoveType)
	{
	case EMuksiBattleMoveType::GroundPath:
		EndSection = CachedMoveData.GroundPathEndSection;
		break;

	case EMuksiBattleMoveType::Teleport:
		EndSection = CachedMoveData.TeleportEndSection;
		break;

	default:
		return;
	}

	if (EndSection.IsNone())
		return;

	const bool bJumpedToSection = AnimationComponent->JumpCurrentMontageToSection(EndSection);

	UE_LOG(LogTemp, Log, TEXT("[MoveExecution] Request End Section. MoveType=%d Section=%s Result=%s"), static_cast<int32>(CachedMoveData.MoveType), *EndSection.ToString(), bJumpedToSection ? TEXT("Success") : TEXT("Failed"));
}

void UMoveExecution::FinishMoveExecution(bool bRequestEndAnimation)
{
	if (IsExecutionFinished())
	{
		return;
	}

	if (bRequestEndAnimation)
	{
		RequestMovementEndAnimation();
	}

	MovingCharacter = nullptr;
	GridManager = nullptr;
	NavigationComponent = nullptr;
	MovementComponent = nullptr;
	AnimationComponent = nullptr;

	CachedMoveData = FMoveExecutionData();
	StartCoord = FHexOffsetCoord(INDEX_NONE, INDEX_NONE);
	DestinationCoord = FHexOffsetCoord(INDEX_NONE, INDEX_NONE);
	GridWorldType = EBattleSimulationWorldType::PlayerActualEnemyActual;
	bHasMoveData = false;

	FinishExecution(CachedOnFinished);
}

const UScriptStruct* UMoveExecution::GetExecutionDataStruct() const
{
	return FMoveExecutionData::StaticStruct();
}

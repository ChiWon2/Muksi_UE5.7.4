#pragma once

#include "CoreMinimal.h"
#include "Muksi/Contents/Battle/Execution/Data/BattleExecutionTypes.h"
#include "Muksi/Contents/Battle/FX/MuksiBattleFXTypes.h"
#include "PlayMontageExecutionData.generated.h"

USTRUCT(BlueprintType)
struct FPlayMontageExecutionData : public FBattleExecutionData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Animation")
	FName AnimKey = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Animation", meta = (ClampMin = "0.0"))
	float PlayRate = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Animation")
	bool bWaitForMontageEnd = true;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "FX")
	TArray<FBattleFXKeyMapping> FXMappings;
};
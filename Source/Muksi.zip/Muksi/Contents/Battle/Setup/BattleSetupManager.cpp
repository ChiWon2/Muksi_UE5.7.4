#include "Muksi/Contents/Battle/Setup/BattleSetupManager.h"

#include "Engine/World.h"
#include "Muksi/Contents/Battle/BattleManager.h"
#include "Muksi/Contents/Battle/Character/BattleCharacterBase.h"
#include "Muksi/Contents/Battle/Character/BattleCharacter_Enemy.h"
#include "Muksi/Contents/Battle/Character/BattleCharacter_Player.h"
#include "Muksi/Contents/Battle/Character/BattleStatComponent.h"
#include "Muksi/Contents/Battle/Data/MuksiCharacterDataAsset.h"
#include "Muksi/Contents/Battle/Grid/BattleGridManager.h"
#include "Muksi/Contents/Battle/Movement/MuksiBattleMovementComponent.h"
#include "Muksi/Contents/Battle/Flow/BattlePhaseTask.h"
#include "Muksi/Contents/Battle/Runtime/BattleRuntimeContext.h"
#include "Muksi/Contents/Battle/Setup/AssetPreload/BattleAssetPreloadManager.h"
#include "Muksi/Save/BattleEncounterSubsystem.h"

ABattleSetupManager::ABattleSetupManager()
{
    PrimaryActorTick.bCanEverTick = false;
}

void ABattleSetupManager::BeginPlay()
{
    Super::BeginPlay();
}

void ABattleSetupManager::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    UnbindBattleEndEvents();
    if (BattleManager)
        BattleManager->PhaseEntryRequestedDelegate.RemoveDynamic(this, &ABattleSetupManager::HandlePhaseEntryRequested);

    if (AssetPreloadManager)
        AssetPreloadManager->ReleaseLoadedAssets();

    AssetPreloadManager = nullptr;
    BattleGridManager = nullptr;
    BattleManager = nullptr;

    Super::EndPlay(EndPlayReason);
}

bool ABattleSetupManager::InitializeBattleFlow(ABattleManager* InBattleManager, ABattleGridManager* InBattleGridManager)
{
    if (!IsValid(InBattleManager) || !IsValid(InBattleGridManager))
        return false;

    BattleManager = InBattleManager;
    BattleGridManager = InBattleGridManager;
    AssetPreloadManager = NewObject<UBattleAssetPreloadManager>(this);

    if (!AssetPreloadManager || !AssetPreloadManager->Initialize(BattleManager, RenderPreparationTimeoutSeconds))
        return false;

    BattleManager->PhaseEntryRequestedDelegate.AddUniqueDynamic(this, &ABattleSetupManager::HandlePhaseEntryRequested);
    return true;
}

bool ABattleSetupManager::ShouldHandlePhaseEntry(EBattlePhase Phase) const
{
    return Phase == EBattlePhase::ReadyStart || Phase == EBattlePhase::ReadyEnd || Phase == EBattlePhase::BattleEnd;
}

void ABattleSetupManager::HandlePhaseEntryRequested(EBattlePhase OldPhase, EBattlePhase NewPhase, UBattlePhaseTaskContext* TaskContext)
{
    (void)OldPhase;

    if (!ShouldHandlePhaseEntry(NewPhase) || !TaskContext)
        return;

    UBattlePhaseTask* Task = TaskContext->RegisterTask(this);
    if (!Task)
        return;

    if (!IsValid(BattleManager) || !IsValid(BattleGridManager))
    {
        UE_LOG(LogTemp, Error, TEXT("[BattleSetupManager] Failed to resolve phase entry dependencies."));
        Task->Complete();
        return;
    }

    switch (NewPhase)
    {
    case EBattlePhase::ReadyStart:
        if (!PrepareReadyData(Task))
            Task->Complete();

        return;

    case EBattlePhase::ReadyEnd:
        PrepareReadyEnd();
        Task->Complete();
        return;

    case EBattlePhase::BattleEnd:
        if (AssetPreloadManager)
            AssetPreloadManager->ReleaseLoadedAssets();

        Task->Complete();
        return;

    default:
        Task->Complete();
        return;
    }
}

bool ABattleSetupManager::PrepareReadyData(UBattlePhaseTask* Task)
{
    LoadEncounterEnemyCharacterData();

    if (!IsValid(PlayerCharacterDataAsset))
    {
        UE_LOG(LogTemp, Error, TEXT("[BattleSetupManager] Player character data is invalid."));
        return false;
    }

    if (!IsValid(EnemyCharacterDataAsset))
    {
        UE_LOG(LogTemp, Error, TEXT("[BattleSetupManager] Enemy character data is invalid."));
        return false;
    }

    if (!AssetPreloadManager || !IsValid(Task))
        return false;

    TWeakObjectPtr<ABattleSetupManager> WeakThis(this);
    TWeakObjectPtr<UBattlePhaseTask> WeakTask(Task);

    const bool bPreloadStarted = AssetPreloadManager->LoadAssetsForBattle(PlayerCharacterDataAsset, EnemyCharacterDataAsset, [WeakThis, WeakTask](bool bSuccess)
    {
        if (!bSuccess && WeakThis.IsValid())
            UE_LOG(LogTemp, Error, TEXT("[BattleSetupManager] Failed to preload battle assets."));

        if (WeakTask.IsValid())
            WeakTask->Complete();
    });

    if (!bPreloadStarted)
    {
        UE_LOG(LogTemp, Error, TEXT("[BattleSetupManager] Failed to start battle asset preload."));
        return false;
    }

    return true;
}

bool ABattleSetupManager::PrepareReadyEnd()
{
    if (!CreateBattleCharacters())
    {
        UE_LOG(LogTemp, Error, TEXT("[BattleSetupManager] Failed to create battle characters."));
        return false;
    }

    BindBattleEndEvents();
    return true;
}

void ABattleSetupManager::LoadEncounterEnemyCharacterData()
{
    UBattleEncounterSubsystem* BattleEncounterSubsystem = UBattleEncounterSubsystem::Get(this);
    if (!IsValid(BattleEncounterSubsystem))
    {
        UE_LOG(LogTemp, Warning, TEXT("[BattleSetupManager] BattleEncounterSubsystem is invalid. Using configured enemy data."));
        return;
    }

    UMuksiCharacterDataAsset* EncounterEnemyData = BattleEncounterSubsystem->GetCurrentEnemyData();
    if (!IsValid(EncounterEnemyData))
    {
        UE_LOG(LogTemp, Warning, TEXT("[BattleSetupManager] Current enemy data is invalid. Using configured enemy data."));
        return;
    }

    EnemyCharacterDataAsset = EncounterEnemyData;
}

bool ABattleSetupManager::CreateBattleCharacters()
{
    if (!IsValid(BattleManager) || !IsValid(BattleGridManager))
    {
        return false;
    }

    UBattleRuntimeContext* RuntimeContext = BattleManager->GetBattleRuntimeContext();
    if (!IsValid(RuntimeContext))
    {
        return false;
    }

    UWorld* World = GetWorld();
    if (!World || !IsValid(PlayerCharacterDataAsset) || !IsValid(EnemyCharacterDataAsset))
    {
        return false;
    }

    TSubclassOf<ABattleCharacterBase> PlayerClass = PlayerCharacterDataAsset->BattleCharacterClass;
    TSubclassOf<ABattleCharacterBase> EnemyClass = EnemyCharacterDataAsset->BattleCharacterClass;
    if (!PlayerClass || !EnemyClass)
    {
        return false;
    }

    UnbindBattleEndEvents();

    if (ABattleCharacter_Player* ExistingPlayer = RuntimeContext->GetPlayerCharacter())
    {
        ExistingPlayer->Destroy();
    }

    if (ABattleCharacter_Enemy* ExistingEnemy = RuntimeContext->GetEnemyCharacter())
    {
        ExistingEnemy->Destroy();
    }

    RuntimeContext->SetBattleCharacters(nullptr, nullptr);

    const FTransform SpawnTransform = BattleManager->GetActorTransform();
    ABattleCharacter_Player* PlayerCharacter = World->SpawnActor<ABattleCharacter_Player>(PlayerClass, SpawnTransform);
    if (!IsValid(PlayerCharacter))
    {
        return false;
    }

    PlayerCharacter->SetCharacterData(PlayerCharacterDataAsset, BattleManager);

    ABattleCharacter_Enemy* EnemyCharacter = World->SpawnActor<ABattleCharacter_Enemy>(EnemyClass, SpawnTransform);
    if (!IsValid(EnemyCharacter))
    {
        PlayerCharacter->Destroy();
        return false;
    }

    EnemyCharacter->SetCharacterData(EnemyCharacterDataAsset, BattleManager);

    BattleGridManager->PlaceCharacter(EBattleSimulationWorldType::PlayerActualEnemyActual, PlayerCharacter, StartPlayerCoord);
    BattleGridManager->PlaceCharacter(EBattleSimulationWorldType::PlayerActualEnemyActual, EnemyCharacter, StartEnemyCoord);

    // PlaceCharacter() applies the tile spawn transform, including its rotation.
    // Face the combatants only after both final world positions are established.
    FaceCharactersTowardEachOther(PlayerCharacter, EnemyCharacter);

    RuntimeContext->SetBattleCharacters(PlayerCharacter, EnemyCharacter);
    return true;
}

void ABattleSetupManager::FaceCharactersTowardEachOther(ABattleCharacterBase* PlayerCharacter, ABattleCharacterBase* EnemyCharacter) const
{
    if (!IsValid(PlayerCharacter) || !IsValid(EnemyCharacter))
    {
        return;
    }

    FVector PlayerToEnemy = EnemyCharacter->GetActorLocation() - PlayerCharacter->GetActorLocation();

    // Characters should only turn on the ground plane.
    // Ignoring Z prevents small terrain-height differences from introducing pitch.
    PlayerToEnemy.Z = 0.0f;

    if (PlayerToEnemy.IsNearlyZero())
    {
        return;
    }

    const UMuksiBattleMovementComponent* PlayerMovement = PlayerCharacter->GetBattleMovementComponent();
    const UMuksiBattleMovementComponent* EnemyMovement = EnemyCharacter->GetBattleMovementComponent();

    // Keep initial facing consistent with the rotation/movement system.
    // Character meshes can have their own forward-axis correction (for example -90 degrees),
    // so apply the same MovementYawOffset used by UMuksiBattleMovementComponent.
    const float PlayerYawOffset = IsValid(PlayerMovement) ? PlayerMovement->MovementYawOffset : 0.0f;
    const float EnemyYawOffset = IsValid(EnemyMovement) ? EnemyMovement->MovementYawOffset : 0.0f;

    const float PlayerYaw = PlayerToEnemy.Rotation().Yaw + PlayerYawOffset;
    const float EnemyYaw = (-PlayerToEnemy).Rotation().Yaw + EnemyYawOffset;

    PlayerCharacter->SetActorRotation(FRotator(0.0f, PlayerYaw, 0.0f));
    EnemyCharacter->SetActorRotation(FRotator(0.0f, EnemyYaw, 0.0f));
}

void ABattleSetupManager::BindBattleEndEvents()
{
    UBattleRuntimeContext* RuntimeContext = IsValid(BattleManager) ? BattleManager->GetBattleRuntimeContext() : nullptr;
    if (!IsValid(RuntimeContext))
    {
        return;
    }

    ABattleCharacter_Player* PlayerCharacter = RuntimeContext->GetPlayerCharacter();
    ABattleCharacter_Enemy* EnemyCharacter = RuntimeContext->GetEnemyCharacter();

    if (!IsValid(PlayerCharacter) || !IsValid(EnemyCharacter))
    {
        return;
    }

    if (UBattleStatComponent* PlayerStatComponent = PlayerCharacter->GetBattleStatComponent())
    {
        PlayerStatComponent->OnDead.RemoveDynamic(this, &ABattleSetupManager::HandleBattleCharacterDead);
        PlayerStatComponent->OnDead.AddUniqueDynamic(this, &ABattleSetupManager::HandleBattleCharacterDead);
    }

    if (UBattleStatComponent* EnemyStatComponent = EnemyCharacter->GetBattleStatComponent())
    {
        EnemyStatComponent->OnDead.RemoveDynamic(this, &ABattleSetupManager::HandleBattleCharacterDead);
        EnemyStatComponent->OnDead.AddUniqueDynamic(this, &ABattleSetupManager::HandleBattleCharacterDead);
    }
}

void ABattleSetupManager::UnbindBattleEndEvents()
{
    UBattleRuntimeContext* RuntimeContext = IsValid(BattleManager) ? BattleManager->GetBattleRuntimeContext() : nullptr;
    if (!IsValid(RuntimeContext))
    {
        return;
    }

    if (ABattleCharacter_Player* PlayerCharacter = RuntimeContext->GetPlayerCharacter())
    {
        if (UBattleStatComponent* PlayerStatComponent = PlayerCharacter->GetBattleStatComponent())
        {
            PlayerStatComponent->OnDead.RemoveDynamic(this, &ABattleSetupManager::HandleBattleCharacterDead);
        }
    }

    if (ABattleCharacter_Enemy* EnemyCharacter = RuntimeContext->GetEnemyCharacter())
    {
        if (UBattleStatComponent* EnemyStatComponent = EnemyCharacter->GetBattleStatComponent())
        {
            EnemyStatComponent->OnDead.RemoveDynamic(this, &ABattleSetupManager::HandleBattleCharacterDead);
        }
    }
}

void ABattleSetupManager::HandleBattleCharacterDead(ABattleCharacterBase* DeadCharacter)
{
    if (BattleManager)
        BattleManager->NotifyBattleCharacterDead(DeadCharacter);
}

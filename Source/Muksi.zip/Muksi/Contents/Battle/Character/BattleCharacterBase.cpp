// Fill out your copyright notice in the Description page of Project Settings.


#include "Muksi/Contents/Battle/Character/BattleCharacterBase.h"

#include "BattleCardComponent.h"
#include "BattleSkillComponent.h"
#include "BattleStatComponent.h"
#include "Components/BoxComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Muksi/Contents/Battle/Data/MuksiCharacterDataAsset.h"
#include "Muksi/Contents/Battle/StatusEffect/MuksiStatusEffectComponent.h"
#include "Muksi/Contents/Battle/Animations/MuksiBattleAnimationComponent.h"
#include "Muksi/Contents/Battle/Camera/CharacterCameraComponent.h"
#include "Muksi/Contents/Battle/Movement/MuksiBattleMovementComponent.h"
#include "Muksi/Contents/Battle/FX/MuksiBattleFXComponent.h"
#include "Muksi/Contents/Battle/Passive/CharacterPassiveComponent.h"


// Sets default values
ABattleCharacterBase::ABattleCharacterBase()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(
		TEXT("SceneRoot")
	);
	SetRootComponent(SceneRoot);

	MeshComponent = CreateDefaultSubobject<USkeletalMeshComponent>(
		TEXT("MeshComponent")
	);
	MeshComponent->SetupAttachment(SceneRoot);

	ClickCollision = CreateDefaultSubobject<UBoxComponent>(
		TEXT("ClickCollision")
	);
	ClickCollision->SetupAttachment(SceneRoot);

	ClickCollision->SetCollisionEnabled(
		ECollisionEnabled::QueryOnly
	);

	ClickCollision->SetCollisionResponseToAllChannels(
		ECR_Ignore
	);

	ClickCollision->SetCollisionResponseToChannel(
		ECC_Visibility,
		ECR_Block
	);

	ClickCollision->OnClicked.AddDynamic(
		this,
		&ABattleCharacterBase::HandleClicked
	);

	// 메시 자체는 클릭 판정을 받지 않게 설정
	MeshComponent->SetCollisionResponseToChannel(
		ECC_Visibility,
		ECR_Ignore
	);
	
	//스킬 위젯 액터 소환 위치
	SkillInfoAnchorComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SkillInfoAnchorComponent"));
	SkillInfoAnchorComponent->SetupAttachment(RootComponent);
	//카메라 포커스 잡는 컴포넌트는 소켓에 잡기(클릭 확대용)
	ClickCameraFocusComponent = CreateDefaultSubobject<UCharacterCameraComponent>(TEXT("ClickCameraFocusComponent"));
	ClickCameraFocusComponent->SetupAttachment(SceneRoot);
	ClickCameraFocusComponent->SetRelativeLocation(FVector(-40.0f, 150.0f, 160.0f));
	//BattleAction 직전 카메라 포커스
	ActionCameraFocusComponent = CreateDefaultSubobject<UCharacterCameraComponent>(TEXT("ActionCameraFocusComponent"));
	ActionCameraFocusComponent->SetupAttachment(RootComponent);
	ActionCameraFocusComponent->SetRelativeLocation(FVector(0.0f, 0.0f, 168.0f));
	//카메라 포커스 잡는 컴포넌트는 소켓에 잡기(공격 애니메이션 연출용)
	AttackCameraFocusComponent = CreateDefaultSubobject<UCharacterCameraComponent>(TEXT("AttackCameraFocusComponent"));
	AttackCameraFocusComponent->SetupAttachment(MeshComponent,TEXT("AttackCameraSocket"));
	AttackCameraFocusComponent->bEditableWhenInherited = true;
	
	PassiveComponent = CreateDefaultSubobject<UCharacterPassiveComponent>(TEXT("PassiveComponent"));

	StatusEffectComponent = CreateDefaultSubobject<UMuksiStatusEffectComponent>(TEXT("StatusEffectComponent"));

	BattleAnimationComponent = CreateDefaultSubobject<UMuksiBattleAnimationComponent>(TEXT("BattleAnimationComponent"));

	BattleMovementComponent = CreateDefaultSubobject<UMuksiBattleMovementComponent>(TEXT("BattleMovementComponent"));

	BattleFXComponent = CreateDefaultSubobject<UMuksiBattleFXComponent>(TEXT("BattleFXComponent"));

	BattleStatComponent = CreateDefaultSubobject<UBattleStatComponent>(TEXT("BattleStatComponent"));
	
	BattleSkillComponent = CreateDefaultSubobject<UBattleSkillComponent>(TEXT("BattleSkillComponent"));
}


float ABattleCharacterBase::GetCurrentHP() const
{
	if (BattleStatComponent){return BattleStatComponent->GetCurrentHP();}
	return -1.f;
}

void ABattleCharacterBase::SetCurrentHP(float NewHP)
{
	if (BattleStatComponent){BattleStatComponent->SetCurrentHP(NewHP);}
}

FVector2D ABattleCharacterBase::GetCurrentSelectCardTime() const
{
	if (CharacterData.IsValid()){return FVector2D(CharacterData.CharacterAsset->CardSelectTimeMin, CharacterData.CharacterAsset->CardSelectTimeMax);}
	return FVector2D(1.f,1.f);
}


float ABattleCharacterBase::GetCharacterSpeed() const
{
	if (BattleStatComponent)
		return BattleStatComponent->GetSpeed();

	return CharacterData.CharacterSpeed;
}

void ABattleCharacterBase::SetCharacterData(UMuksiCharacterDataAsset* InCharacterData, ABattleManager* BattleManager)
{
	CharacterData.Init_DataAsset(InCharacterData);
	if (!CharacterData.IsValid())
	{
		UE_LOG(LogTemp, Warning, TEXT("BattleCharacterBase SetCharacterData failed: CharacterDataAsset is null"));
		return;
	}
	
	if (!PassiveComponent)
	{
		UE_LOG(LogTemp, Error, TEXT("PassiveComponent is null (BattleCharacterBase.cpp)"));
		return;
	}
	StatusEffectComponent->Initialize(BattleManager);
	PassiveComponent->InitializePassives(CharacterData.CharacterPassives);
	
	InitializeBattleStats();
	
	
	if (!BattleSkillComponent)
	{
		UE_LOG(LogTemp, Error, TEXT("BattleSkillComponent is null (BattleCharacterBase.cpp)"));
		return;
	}

	BattleSkillComponent->Initialize(InCharacterData->CharacterDeck, InCharacterData->MaxSkillCost);
}

void ABattleCharacterBase::InitializeBattleStats()
{
	if (!BattleStatComponent)
	{
		UE_LOG(LogTemp, Error, TEXT("BattleStatComponent is null (BattleCharacterBase.cpp)"));
		return;
	}
	FBattleStats BattleStats = FBattleStats();
	BattleStats.Attack = CharacterData.AttackValue;
	BattleStats.Defense = CharacterData.DefenseValue;
	BattleStats.Speed = CharacterData.CharacterSpeed;
	BattleStats.HP = CharacterData.MaxHP;
	BattleStatComponent->InitializeStats(BattleStats);
}

void ABattleCharacterBase::CopySimulationStateFrom(const ABattleCharacterBase& SourceCharacter)
{
	CharacterData = FCharacterData();
	CharacterData.CurrentPosition = SourceCharacter.CharacterData.CurrentPosition;
	CharacterData.CharacterAsset = SourceCharacter.CharacterData.CharacterAsset;
	CharacterData.MaxHP = SourceCharacter.CharacterData.MaxHP;
	CharacterData.AttackValue = SourceCharacter.CharacterData.AttackValue;
	CharacterData.DefenseValue = SourceCharacter.CharacterData.DefenseValue;
	CharacterData.CharacterSpeed = SourceCharacter.CharacterData.CharacterSpeed;

	if (BattleStatComponent && SourceCharacter.BattleStatComponent)
		BattleStatComponent->CopyRuntimeStateFrom(*SourceCharacter.BattleStatComponent);
}

void ABattleCharacterBase::HandleClicked(UPrimitiveComponent* TouchedComponent, FKey ButtonPressed)
{
	UE_LOG(LogTemp, Warning, TEXT("BattleCharacter clicked! Actor: %s, Button: %s"),
		*GetNameSafe(this),
		*ButtonPressed.ToString());
}


TArray<TObjectPtr<UCharacterPassive>> ABattleCharacterBase::GetCharacterPassives()
{
	if (!PassiveComponent)
	{
		UE_LOG(LogTemp, Error, TEXT("PassiveComponent is Error (BattleCharacterBase.cpp)"));
		return TArray<TObjectPtr<UCharacterPassive>>();
	}
	return PassiveComponent->GetCharacterPassives();
}

FTransform ABattleCharacterBase::GetCameraFocusTransform() const
{
	if (IsValid(ClickCameraFocusComponent))
	{
		return ClickCameraFocusComponent
			->GetComponentTransform();
	}

	return GetActorTransform();
}



void ABattleCharacterBase::OnSelected()
{
	UE_LOG(LogTemp, Warning, TEXT("Selected"));
}

void ABattleCharacterBase::OnDeselected()
{
	UE_LOG(LogTemp, Warning, TEXT("Deselected"));
}


// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "BattleCardComponent.generated.h"

class UMuksiBattleCardDataAsset;

UENUM(BlueprintType)
enum class EBattleCardInstanceSource : uint8
{
	Deck,
	Panic
};

USTRUCT(BlueprintType)
struct FBattleCardInstance
{
	GENERATED_BODY()

public:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta = (IgnoreForMemberInitializationTest))
	FGuid InstanceId;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	TObjectPtr<UMuksiBattleCardDataAsset> CardData = nullptr;
	
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	EBattleCardInstanceSource Source = EBattleCardInstanceSource::Deck;

public:
	FBattleCardInstance()
		: InstanceId(FGuid::NewGuid())
	{
	}

	explicit FBattleCardInstance(
	UMuksiBattleCardDataAsset* InCardData,
	EBattleCardInstanceSource InSource = EBattleCardInstanceSource::Deck)
	: InstanceId(FGuid::NewGuid())
	, CardData(InCardData)
	, Source(InSource)
	{
	}

	bool IsValid() const
	{
		return CardData != nullptr;
	}
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class MUKSI_API UBattleCardComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UBattleCardComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;
	
public:
	void Initialize(const TArray<UMuksiBattleCardDataAsset*>& InDeck);
	
	const TArray<FBattleCardInstance>& GetCurrentHand() const
	{
		return CurrentHand;
	}

	const TArray<FBattleCardInstance>& GetCommittedCards() const
	{
		return CommittedCards;
	}

	int32 GetCurrentHandCount() const
	{
		return CurrentHand.Num();
	}
	
	const TArray<TObjectPtr<UMuksiBattleCardDataAsset>>& GetFullDeck() const
	{
		return FullDeck;
	}
	
	const FBattleCardInstance* FindHandCardById(const FGuid& InstanceId) const;
	const FBattleCardInstance* FindHandCardByData(UMuksiBattleCardDataAsset* CardData) const;
	const FBattleCardInstance* GetCommittedCardByExchange(int32 ExchangeIndex) const;
	
	
	bool CommitCard(const FGuid& InstanceId);
	bool ReturnCommittedCard(const FGuid& InstanceId);
	
	bool ReplaceHandCard(const FGuid& InstanceId, UMuksiBattleCardDataAsset* NewCardData);
	void ConsumeCommittedCards();
	bool RefillHandIfEmpty();
	
	bool DiscardRandomHandCard(FBattleCardInstance& OutDiscardedCard);
	bool CommitPanicCard(UMuksiBattleCardDataAsset* PanicCard, FBattleCardInstance& OutCommittedCard);
private:
	
	
	UPROPERTY(Transient)
	TArray<TObjectPtr<UMuksiBattleCardDataAsset>> FullDeck;//전체 덱

	UPROPERTY(Transient)
	TArray<FBattleCardInstance> CurrentHand;//손패 인스턴스

	UPROPERTY(Transient)
	TArray<FBattleCardInstance> CommittedCards;//ExchangeSlot에 넣은 카드 인스턴스
		
};

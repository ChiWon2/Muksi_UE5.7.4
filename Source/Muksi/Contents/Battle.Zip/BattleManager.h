// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Muksi/Contents/Battle/Hex/HexOffsetCoord.h"
#include "GameFramework/Actor.h"
#include "Muksi/Contents/Battle/Data/BattleAction.h"
#include "Muksi/Contents/Battle/Data/BattlePhase.h"

#include "Muksi/Contents/Battle/Targeting/Context/TargetingInputContext.h"
#include "Muksi/Contents/Battle/Targeting/Context/TargetingResult.h"
#include "BattleManager.generated.h"

class UMuksiCharacterDataAsset;
class ABattleCharacterBase;
class ABattleCharacter_Player;
class ABattleCharacter_Enemy;

class UMuksiBattleCardDataAsset;
class ATargetPoint;

class ABattleGridManager;
class ABattleSequenceManager;
class UBattleTargetingManager;
class ABattleSimulationManager;

class UWidget_BattleMainScreen;


DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnBattlePhaseChanged, EBattlePhase, NewPhase);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnBattleReady);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnBattleStarted);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnRoundStarted);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnRoundEnded);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnExchangeStarted);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnExchangeEnded);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnAttackStarted);


DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnAttack,int32,AttackNumber);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnAttackEnded);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnBattleEnded);

UCLASS()
class MUKSI_API ABattleManager : public AActor
{
	GENERATED_BODY()

public:
	ABattleManager();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:

	// =========================
	// Battle Flow
	// =========================

	UFUNCTION(BlueprintPure, Category = "Battle")
	int32 GetCurrentRound() const { return CurrentRound; }

	UFUNCTION(BlueprintPure, Category = "Battle")
	int32 GetCurrentExchange() const { return CurrentExchange; }

	UFUNCTION(BlueprintPure, Category = "Battle")
	int32 GetCurrentAttack() const { return CurrentAttack; }

	UFUNCTION(BlueprintPure, Category = "Battle")
	bool IsBattleStarted() const { return bBattleStarted; }

protected:
	// 나중에 전투 종료 조건을 여기서 판단
	bool ShouldEndBattle() const;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Battle")
	int32 CurrentRound = 0;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Battle")
	int32 CurrentExchange = 0;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Battle")
	int32 CurrentAttack = 0;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Battle")
	bool bBattleStarted = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Battle|Rule")
	int32 MaxExchangeCount = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Battle|Rule")
	int32 MaxAttackCount = 3;

public:
	// =========================
	// Events
	// =========================

	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnBattlePhaseChanged OnBattlePhaseChanged;

	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnBattleReady OnBattleReady;

	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnBattleStarted OnBattleStarted;

	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnRoundStarted OnRoundStarted;
	
	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnRoundEnded OnRoundEnded;

	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnExchangeStarted OnExchangeStarted;
	
	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnExchangeEnded OnExchangeEnded;

	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnAttack OnAttack;

	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnAttackStarted OnAttackStarted;

	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnAttackEnded OnAttackEnded;

	UPROPERTY(BlueprintAssignable, Category = "Battle|Event")
	FOnBattleEnded OnBattleEnded;

	// =========================
	// Card
	// =========================

public:

	UPROPERTY(BlueprintReadOnly, Category = "Battle|Attack")
	TObjectPtr<UMuksiBattleCardDataAsset> AttackBattleCardDataAsset = nullptr;
	
protected:
	void CreateCharacter();

	//월드 레벨 오브젝트 관리
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Battle|Grid")
	TObjectPtr<ABattleGridManager> BattleGridManager = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Battle|Sequence")
	TObjectPtr<ABattleSequenceManager> BattleSequenceManager = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Battle|Simulation")
	TObjectPtr<ABattleSimulationManager> BattleSimulationManager = nullptr;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Battle|Character")
	TObjectPtr<ABattleCharacter_Player> PlayerBattleCharacter = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Battle|Character")
	TObjectPtr<ABattleCharacter_Enemy> EnemyBattleCharacter = nullptr;

	UPROPERTY(Transient)
	TObjectPtr<UBattleTargetingManager> BattleTargetingManager = nullptr;

	UPROPERTY()
	int32 CurrentAttackActionIndex = 0;

	//Battle 실행 관련 캐릭터 이동
	//Battle Mouse 관련 함수
public:
	bool StartCurrentCardTargeting(UMuksiBattleCardDataAsset* Card);
	bool UpdateCurrentCardTargeting(const FTargetingInputContext& InputContext);
	bool ConfirmCurrentCardTargeting();
	void CancelCurrentCardTargeting();
	bool IsCardTargeting() const;

	UFUNCTION(BlueprintPure, Category = "Battle|Grid")
	ABattleGridManager* GetBattleGridManager() const { return BattleGridManager; }

	//=========================================GetSet====================================================================
public:
	TObjectPtr<ABattleCharacter_Player> GetPlayerBattleCharacter() { return PlayerBattleCharacter; }
	TObjectPtr<ABattleCharacter_Enemy> GetEnemyBattleCharacter() { return EnemyBattleCharacter; }

	UFUNCTION(BlueprintPure, Category = "Battle|Data")
	UMuksiCharacterDataAsset* GetPlayerCharacterDataAsset() const { return TestPlayerCharacterDataAsset; }

	UFUNCTION(BlueprintPure, Category = "Battle|Data")
	UMuksiCharacterDataAsset* GetEnemyCharacterDataAsset() const { return TestEnemyCharacterDataAsset; }

	UMuksiBattleCardDataAsset* GetBattleCardDataAssetToExchange_Player(int32 ExchangeCount);
	UMuksiBattleCardDataAsset* GetBattleCardDataAssetToExchange_Enemy(int32 ExchangeCount);

	FHexOffsetCoord GetPlayerPoint() const;
	FHexOffsetCoord GetEnemyPoint() const;

	UFUNCTION(BlueprintPure, Category = "Battle")
	EBattlePhase GetCurrentPhase() const { return CurrentPhase; }

	void ChangePhase(EBattlePhase NewPhase);

	UWidget_BattleMainScreen* GetBattleMainScreen() { return BattleMainScreen; }
	void SetBattleMainScreen(TObjectPtr<UWidget_BattleMainScreen> BattleWidget) { BattleMainScreen = BattleWidget; }

	//==================================================================================================================

	//전투 파이프라인 관련
	//Ready <- 필요한 포인터 정보 등등 받는 단계 (첫 1프레임 이내)
	//Battle 전투<- 실질적 작동 플레이어가 전투를 하는 단계(첫 1프레임 이후 이 레벨 끝날 때까지)
	//Round 국<- 3번의 합/ 3번의 공격을 한 묶음으로 정의하는 의미
	//Exchange 합 <- Battle Card를 제시하고 방향 설정 까지의 단계. 3번 반복 한다. 플레이어 조작이 들어가는 단계
	//Attack 공격 <- Exchange 때 제시한 카드/방향을 실행하는 단계. 캐릭터의 스탯 계산 위주로 실행
	/*
	 * 1. 캐릭터의 속도 값 계산
	 * 2. 더 빠른 캐릭터의 카드 먼저 실행
	 * 3. 그 이후 상대 캐릭터 카드 실행
	 * 4. 3번 반복 이후 국 종료 다음 국 실행
	 */

	 //=============================================Ready 단계 관련(저장/소환하는 정보)===============================================================
	 //전체 순서
	 //BattleManager->ReadyStart() >>> Widget_BattleMainScreen->ReadyStart() >>> Widget_BattleMainScreen->ReadyEnd() >>> BattleManager->ReadyEnd()
public:
	void ReadyStart();
	void ReadyEnd();

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Battle|Spawn")
	TObjectPtr<ATargetPoint> PlayerSpawnPoint = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Battle|Spawn")
	TObjectPtr<ATargetPoint> EnemySpawnPoint = nullptr;

protected:
	UPROPERTY()
	TObjectPtr<UWidget_BattleMainScreen> BattleMainScreen = nullptr;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Battle")
	EBattlePhase CurrentPhase = EBattlePhase::None;

	//Player Character Data Asset <- 테스트 용도 (원래 계획은 원래 월드의 플레이어 정보를 토대로 생성하는 데이터)
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Battle|Test Data")
	TObjectPtr<UMuksiCharacterDataAsset> TestPlayerCharacterDataAsset = nullptr;

	// Enemy Character Data Asset <- 원래 용도는 다른 이벤트에서 받아오는 데이터 에셋
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Battle|Test Data")
	TObjectPtr<UMuksiCharacterDataAsset> TestEnemyCharacterDataAsset = nullptr;

	UPROPERTY(EditAnywhere, Category = "Grid|Character")
	FHexOffsetCoord StartPlayerPoint = FHexOffsetCoord(0, 0);

	UPROPERTY(EditAnywhere, Category = "Grid|Character")
	FHexOffsetCoord StartEnemyPoint = FHexOffsetCoord(4, 4);

public:
	bool StartCurrentExchangeSimulation();
	void HandleSimulationExchangeFinished(int32 FinishedExchangeIndex);
	void HandleBattleSimulationFinished();
	void CompleteExchangePresentation(int32 FinishedExchangeIndex);

	ABattleGridManager* GetCurrentTargetingGridManager() const;
	ABattleCharacterBase* GetCurrentTargetingSourceCharacter() const;
	ABattleCharacterBase* ResolveCurrentTargetingCharacter(ABattleCharacterBase* Character) const;

	//=============================================Battle 단계 관련===============================================================
public:
	void BattleStart();
	void BattleEnd();

	//===============================================국 관련 ===========================================================
	//--------------------------------Battle 관련 턴 흐름 관리 함수 <국>--------------------------------------------------
	//국 시작	Round 시작
public:
	void RoundStart();
	void RoundEnd();



	//===============================================합 관련 ===========================================================
	//---------------------------------Battle 관련 턴 흐름 관리 함수 <합>--------------------------------------------------
	//합 시작	Exchange 시작

	//1합 시작
	//1합 종료

	//2합 시작
	//2합 종료

	//3합 시작
	//3합 종료

	//합 종료

public:
	void ExchangeStart();

	void Exchange1Start();
	void Exchange1End();

	void Exchange2Start();
	void Exchange2End();

	void Exchange3Start();
	void Exchange3End();

	void ExchangeEnd();

	void ExchangeN_EndReady();
	void ExchangeN_End(int32 InIndex);


	//합 도중 쓰는 함수
public:
	//합 도중 선택 된 카드 방향 정하기
	void ExchangeCardDir(UMuksiBattleCardDataAsset* ExchangeCard);

	//합 정한 카드 그리드 정하고 공격 구조체 생성함수
	void SetPlayerBattleAction();

	//Enemy가 정한 카드 그리드 정하고 공격 구조체 생성함수
	void SetEnemyBattleAction();

	//Player/Enemy가 정한 카드 Grid 표시
	void SetExchangeGrid();

	//==================================================================================================================

	//===============================================공격 관련 ===========================================================
	//---------------------------------Battle 관련 턴 흐름 관리 함수 <공격>--------------------------------------------------
public:
	void SortAttackActions();
	void AttackStart();
	void StartCurrentAttackAction();
	void PlayAttackAction(const FBattleAction& Action);
	void NotifyAttackActionFinished();
	void FinishCurrentAttackAction();
	void AttackEnd();
	void NotifyAttackEndFinished();



protected:
	UPROPERTY()
	TArray<TObjectPtr<UMuksiBattleCardDataAsset>> PlayerSelectedCards;

	UPROPERTY()
	TArray<TObjectPtr<UMuksiBattleCardDataAsset>> EnemySelectedCards;

	UPROPERTY()
	TArray<FBattleAction> AttackActions;

	UPROPERTY()
	TArray<FBattleAction> PlayerSelectAction;

	UPROPERTY()
	TArray<FBattleAction> EnemySelectAction;
};

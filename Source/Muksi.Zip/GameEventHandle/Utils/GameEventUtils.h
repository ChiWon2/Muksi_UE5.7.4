#pragma once

#include "CoreMinimal.h"
#include "StructUtils/InstancedStruct.h"

struct FEvent_StartBattle;
struct FEvent_AcceptQuest;

namespace GameEventUtils
{
    //StartBattle
    FInstancedStruct MakeStartBattle(FName BattleName);

    void ExecuteStartBattle(UObject* WorldContext,FName BattleName);

    //AcceptQuest
    FInstancedStruct MakeAcceptQuest(FName QuestID);

    void ExecuteAcceptQuest(UObject* WorldContext, FName QuestID);

    //CompleteQuest
    FInstancedStruct MakeCompleteQuest(FName QuestID);

    void ExecuteCompleteQuest(UObject* WorldContext, FName QuestID);
    
    //ObjectiveComplete
    FInstancedStruct MakeObjectiveComplete(FName ObjectiveID);

    void ExecuteObjectiveComplete(UObject* WorldContext, FName ObjectiveID);
}
#include"Cond_Equip_Register.h"
#include "../Cond_Equip.h"
#include"../../GameConditionRegistry.h"

// TODO: ���� EquipmentSystem���� ��ü
static bool IsEquipped(UObject* WorldContext, EConditionTarget Target, FName ItemID)
{
	// ���� ����

	if (Target == EConditionTarget::Self)
	{
		if (ItemID == "Sword")
		{
			return true;
		}
	}

	if (Target == EConditionTarget::Target)
	{
		if (ItemID == "Shield")
		{
			return true;
		}
	}

	return false;
}

// ���� ���� üũ
static bool CheckEquip(UObject* WorldContext, const FCond_Equip& Cond)
{
	return IsEquipped(WorldContext, Cond.Target, Cond.ItemID);
}

namespace ConditionRegister
{
	void Register_Cond_Equip()
	{
		FGameConditionRegistry::RegisterCondition<FCond_Equip>(CheckEquip);
	}
}
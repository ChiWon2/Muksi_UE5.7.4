#include"Cond_Quest_Register.h"
#include "../Cond_Quest.h"
#include"../../GameConditionRegistry.h"

// TODO: ���� QuestSystem���� ��ü
static bool IsQuestCompleted(UObject* WorldContext, FName QuestID)
{
	if (QuestID == "MainQuest")
		return true;

	return false;
}

bool CheckQuest(UObject* WorldContext, const FCond_Quest& Cond)
{
	bool bDone = IsQuestCompleted(WorldContext, Cond.QuestID);

	// true == �Ϸ� �ʿ�
	// false == �̿Ϸ� �ʿ�
	return (bDone == Cond.bCompleted);
}

namespace ConditionRegister
{
	void Register_Cond_Quest()
	{
		FGameConditionRegistry::RegisterCondition<FCond_Quest>(CheckQuest);
	}
}
// Fill out your copyright notice in the Description page of Project Settings.


#include "Muksi/Contents/Battle/Character/BattleStatComponent.h"

#include "BattleCharacterBase.h"

// Sets default values for this component's properties
UBattleStatComponent::UBattleStatComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}



void UBattleStatComponent::InitializeStats(const FBattleStats& InStats)
{
	BaseStats = InStats;
	CurrentStats = InStats;

	CurrentStats.HP = FMath::Max(0.0f, CurrentStats.HP);
	CurrentStats.Attack = FMath::Max(0.0f, CurrentStats.Attack);
	CurrentStats.Defense = FMath::Max(0.0f, CurrentStats.Defense);
	CurrentStats.Speed = FMath::Max(0.0f, CurrentStats.Speed);

	CurrentHP = CurrentStats.HP;
	bIsDead = false;
	
}

void UBattleStatComponent::CopyRuntimeStateFrom(const UBattleStatComponent& SourceComponent)
{
	BaseStats = SourceComponent.BaseStats;
	CurrentStats = SourceComponent.CurrentStats;
	CurrentHP = SourceComponent.CurrentHP;
	bIsDead = SourceComponent.bIsDead;
}

float UBattleStatComponent::ApplyDamage(float Damage)
{
	if (bIsDead)
	{
		return 0.0f;
	}

	if (Damage <= 0.0f)
	{
		return 0.0f;
	}
	
	const float FinalDamage = FMath::Max(1.0f, Damage - CurrentStats.Defense);

	const float PreviousHP = CurrentHP;

	CurrentHP = FMath::Clamp(
		CurrentHP - FinalDamage,
		0.0f,
		CurrentStats.HP
	);

	const float AppliedDamage = PreviousHP - CurrentHP;
	
	CurrentStats.HP = CurrentHP;
	
	OnHPChanged.Broadcast(PreviousHP, CurrentStats.HP);

	if (CurrentHP <= 0.0f)
	{
		HandleDeath();
	}

	return AppliedDamage;
}

float UBattleStatComponent::Heal(float HealAmount)
{
	if (bIsDead)
	{
		return 0.0f;
	}

	if (HealAmount <= 0.0f)
	{
		return 0.0f;
	}

	const float PreviousHP = CurrentHP;

	CurrentHP = FMath::Clamp(
		CurrentHP + HealAmount,
		0.0f,
		CurrentStats.HP
	);

	const float AppliedHeal = CurrentHP - PreviousHP;

	OnHPChanged.Broadcast(PreviousHP, CurrentStats.HP);

	return AppliedHeal;
}

void UBattleStatComponent::SetCurrentHP(float NewHP)
{
	if (bIsDead)
	{
		return;
	}

	if (NewHP > BaseStats.HP){NewHP = BaseStats.HP;}
	
	CurrentHP = FMath::Clamp(
		NewHP,
		0.0f,
		CurrentStats.HP
	);
	
	OnHPChanged.Broadcast(CurrentStats.HP,NewHP);
	
	CurrentStats.HP = NewHP;
	if (CurrentHP <= 0.0f)
	{
		HandleDeath();
	}
}

void UBattleStatComponent::RestoreFullHP()
{
	if (bIsDead)
	{
		return;
	}

	CurrentHP = CurrentStats.HP;
	CurrentStats.HP = BaseStats.HP;
	OnHPChanged.Broadcast(CurrentHP, CurrentStats.HP);
}

void UBattleStatComponent::SetCurrentSpeed(float NewSpeed)
{
	if (NewSpeed <= 0.0f)NewSpeed = 0.0f;
	CurrentStats.Speed = NewSpeed;
}

void UBattleStatComponent::HandleDeath()
{
	if (bIsDead)
	{
		return;
	}

	bIsDead = true;
	CurrentHP = 0.0f;
	
	ABattleCharacterBase* OwnerCharacter = Cast<ABattleCharacterBase>(GetOwner());
	checkf(IsValid(OwnerCharacter), TEXT("OwnerCharacter is null BattleStatComponent.cpp"));

	UE_LOG(LogTemp, Error, TEXT("Handle Death (BattleStatComponent.cpp)"));
	OnDead.Broadcast(OwnerCharacter);
}





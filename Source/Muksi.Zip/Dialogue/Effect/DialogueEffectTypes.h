#pragma once

#include "CoreMinimal.h"
#include "DialogueEffectTypes.generated.h"

//DialogueEffectTypes.h

class UTexture2D;
class UMaterialInterface;
class USoundBase;

USTRUCT(BlueprintType)
struct FDialogueEffectPreset
{
    GENERATED_BODY()

    // ȭ�� ���̵� ����
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Config)
    FLinearColor FadeColor = FLinearColor::Black;

    // ���̵� �ð�
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Config)
    float FadeInTime = 0.25f;

    // ��� ��� �̹��� (���� ��)
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Config)
    TSoftObjectPtr<UTexture2D> RarityGemTexture = nullptr;

    // Overlay Material
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Config)
    TSoftObjectPtr<UMaterialInterface> OverlayMaterial = nullptr;

    // ���� ����
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Config)
    TSoftObjectPtr<USoundBase> StartSFX = nullptr;
};
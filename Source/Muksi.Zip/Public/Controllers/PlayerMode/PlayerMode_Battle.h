// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Controllers/PlayerMode/PlayerModeBase.h"
#include "PlayerMode_Battle.generated.h"

class UDataTable;
class UMuksiCharacterDataAsset;
class UWidget_ActivatableBase;
class ABattleCharacterBase;

class ABattleGridManager;
class ABattleGridTile;
class ABattleTargetingManager;

UCLASS(Blueprintable, BlueprintType)
class MUKSI_API UPlayerMode_Battle : public UPlayerModeBase
{
	GENERATED_BODY()

public:
	//~ Begin UPlayerModeBase Interface
	virtual void EnterMode(AMuksiPlayerController* PlayerController) override;
	virtual void ExitMode() override;
	virtual void TickPlayerMode() override;
	virtual int32 GetInputMappingPriority() const override { return 10; }

	virtual void HandleLeftClick(const FInputActionValue& Value) override;
	virtual void HandleRightClick(const FInputActionValue& Value) override;
	virtual void HandleRPressedKey(const FInputActionValue& Value) override;
	//~ End UPlayerModeBase Interface

	UPROPERTY()
	TObjectPtr<ABattleGridTile> HoveredGridTile = nullptr;

	UPROPERTY()
	TObjectPtr<ABattleTargetingManager> BattleTargetingManager = nullptr;

	UPROPERTY()
	TObjectPtr<ABattleGridManager> BattleGridManager = nullptr;

private:
	void UpdateHoveredGridTile(const FHitResult& HitResult, bool bHasHitResult);
	void UpdateCardTargeting(const FHitResult& HitResult, bool bHasHitResult);
	void PushCharacterDataWidget();
	void FocusCameraOnCharacter (ABattleCharacterBase* Character);

	UPROPERTY()
	TObjectPtr<AActor> SelectedActor;
	UPROPERTY(EditDefaultsOnly, Category = "Battle UI")
	TSoftClassPtr<UWidget_ActivatableBase> WidgetCharacterDataClass;
};
